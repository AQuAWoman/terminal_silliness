# terminal_silliness

Just a simple image convolution utility to create text-based art. Probably overdone at this point but this is my take. Enjoy!

Usage:

terminal_silliness \<image path or url> [target width (characters)]
