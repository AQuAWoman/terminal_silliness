from setuptools import setup, find_packages

setup(
    name='terminal_silliness',
    version='0.1.0',
    description='A Python package for image convolution to ASCII art.',
    author='Alex Allen',
    author_email='FingerBlasterStudios@gmail.com',
    packages=find_packages(),
    install_requires=[
        'requests',
        'pillow',
        'numpy',
        'torch',
    ],
    entry_points={
        'console_scripts': [
            'image_convolution=image_convolution.image_convolution:main'
        ]
    },
)